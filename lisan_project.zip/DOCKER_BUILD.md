# Lisan — Сборка APK через Docker

## Быстрый старт

### 1. Установить Docker
- Windows/Mac: https://www.docker.com/products/docker-desktop
- Linux: `sudo apt install docker.io docker-compose`

### 2. Запустить сборку

**Вариант A — Shell скрипт:**
```bash
cd lisan
./build_docker.sh
```

**Вариант B — Docker Compose:**
```bash
cd lisan
docker-compose up
```

**Вариант C — Вручную:**
```bash
cd lisan

# Собрать образ
docker build -t lisan-builder .

# Запустить сборку
docker run --rm -v "$(pwd)/build_output:/output" lisan-builder
```

### 3. Получить APK

После успешной сборки:
```
build_output/app-release.apk
```

### 4. Установить на телефон

**Через ADB (если установлен):**
```bash
adb install build_output/app-release.apk
```

**Вручную:**
- Скопировать APK на телефон
- Открыть файловый менеджер
- Нажать на APK → Установить
- Разрешить установку из неизвестных источников (если спросит)

## Важно про API ключи

Перед сборкой проверь что `.env` содержит твои ключи:

```bash
cat .env
```

Должно быть:
```
DEEPL_API_KEY=9708c7b7-4481-46a5-b7ff-d4d3343b50c0:fx
DEEPSEEK_API_KEY=sk-c76e78ce6711439a8016c1349f483f58
ELEVENLABS_API_KEY=sk_697849cac2d6700e3e54c51821795e9daf2431663bbdb13e
OPENAI_API_KEY=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
```

Если ключи не подхватываются — захардкодь их временно в `lib/services/translation_service.dart`.

## Решение проблем

### Ошибка: "Cannot connect to Docker daemon"
- Запустить Docker Desktop (Windows/Mac)
- Или `sudo systemctl start docker` (Linux)

### Ошибка: "permission denied"
```bash
chmod +x build_docker.sh
```

### Ошибка: "no space left on device"
- Очистить Docker: `docker system prune -a`
- Нужно ~5GB свободного места

### Ошибка: "Failed to build APK"
- Проверить логи Docker
- Запустить с флагом verbose: `docker build --progress=plain -t lisan-builder .`

## Размер и время

| Параметр | Значение |
|----------|----------|
| Размер образа | ~3-4 GB |
| Время сборки образа | 5-10 мин (первый раз) |
| Время сборки APK | 2-5 мин |
| Размер APK | ~20-30 MB |
| Место на диске | ~5 GB |

## Альтернативы

Если Docker не работает:

1. **GitHub Actions** — я могу настроить автоматическую сборку APK при пуше в GitHub
2. **Codemagic** — бесплатный CI/CD для Flutter (200 мин/месяц)
3. **Local Flutter** — собрать на домашнем компьютере

## После установки

1. Открыть приложение "Lisan"
2. Разрешить доступ к микрофону
3. Нажать кнопку микрофона
4. Сказать фразу на русском
5. Отпустить → ждать → услышать перевод

## Обратная связь

После теста сообщи:
- Скорость работы (быстро/медленно)
- Качество перевода
- Качество голоса
- Баги/проблемы
